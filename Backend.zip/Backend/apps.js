// * ========
// *
// * Title :  UpTime Application
// * Description :  UpTime Monitoring Application
// * Author :  MD. Yeachen Abir
// * Title :  4 Octorbar 2024
// * 
// * =========

// ** Dependencies
const server = require('./lib/server');
const workers = require('./lib/workers');

// ** Scaffolding
const apps = {}


// ** Runing application
apps.init = () => {
   // start the server 
   server.init();

   // start the workers
   workers.init();
};

apps.init();


// ** Export
module.exports = apps;