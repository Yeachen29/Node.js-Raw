// * ========
// *
// * Title :  Not Found Page Routers
// * Description :  Not Found  Page Routers
// * Author :  MD. Yeachen Abir
// * Title :  4 Octorbar 2024
// * 
// * =========

// ** Dependencies

// ** Scaffolding
const handlerRoutes = {}

// ** handler Not Found routers
handlerRoutes.notFound = (reqObj, callback) => {
   callback(404, {
      message : "404 Not found page"
   })
}
// ** Export
module.exports = handlerRoutes;