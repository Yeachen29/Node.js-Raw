// * ========
// *
// * Title :  Users Routes
// * Description :  Users Routtes
// * Author :  MD. Yeachen Abir
// * Title :  4 Octorbar 2024
// * 
// * =========

// ** Dependencies
const data = require('./../../lib/data');
const { hash, parseJson } = require('./../../helpers/utilities');
const { verify } = require('./tokens')

// ** Scaffolding
const handler = {}

// ** users routers
handler.users = (reqObject, callback) => {
   
   const reqObj = reqObject;


   const tokenId = typeof(reqObj.header.token) === "string" && reqObj.header.token.trim().length === 20 ? reqObj.header.token : false;
   
   
   const acceptMethod = ['post', 'put', 'get', 'delete'];

   if(acceptMethod.indexOf(reqObj.method) > -1) {
      handler._user[reqObj.method](reqObj, callback, tokenId);
   } else {
      callback(405, {
         message : "Request Method was not accepted"
      })
   }
}

// ** handler request method scaffolding
handler._user = {}

// ** database Directory name
const userDir = "users";

// ** user post method
handler._user.post = (reqObject, callback) => {
   const body = reqObject.bodyObj;

   // ** recived data validation checked
   const firstname = typeof(body.firstname) === "string" && body.firstname.trim().length > 0 ? body.firstname : false;

   const lastname = typeof(body.lastname) === "string" && body.lastname.trim().length > 0 ? body.lastname : false;

   const phone = typeof(body.phone) === "string" && body.phone.trim().length === 11 ? body.phone : false;

   const password = typeof(body.password) === "string" && body.password.trim().length > 0 ? body.password : false;

   const agreement = typeof(body.agreement) === "boolean" && body.agreement === true ? true : false;


   if(firstname && lastname && phone && password && agreement) {
      // ** check the user are exit or not
      data.read(userDir, phone, (readErr, user) => {
         if(readErr && !user){
            const userObj = {
               firstname,
               lastname,
               phone,
               password : hash(password),
               agreement
            }
            // ** create the db
            data.create(userDir, phone, userObj, (createErr)=> {
               if(!createErr) {
                  callback(201, {
                     message : "Sucess to create a user"
                  })
               } else{
                  callback(500, {
                     error : "Server Side Error"
                  })
               }
            })

         } else {
            callback(400, {
               error : "User are already exit"
            })
         }
      })
   } else {
      callback(400, {
         error : "Problem In your request"
      })
   }
}

// ** user get method
handler._user.get = (reqObject, callback, token) => {
   const reqObj = reqObject;
   const param = reqObj.queryStr.id;
   const phone = typeof(param) === "string" && param.trim().length === 11 ? param : false;

   if(phone) {

      // varification check
      verify(token, phone, (veryfied) => {
         if(veryfied) {

            // ** read the db
            data.read(userDir, phone, (err, userData) => {
               const data = { ...parseJson(userData) };
               if(!err && data){
                  delete data.password;
                  callback(200, data);
               } else {
                  callback(404, {
                     error : "User Was not found"
                  })
               }
            })

         } else {
            
            callback(403, {
               error : "Forbidden Request"
            })
         }
      })
   } else {
      callback(400, {
         error : "Bad Request. Phone is invalid"
      })
   }
}

// ** user put method
handler._user.put = (reqObject, callback, token) => {
   const reqObj = reqObject;
   const body = reqObj.bodyObj;
   const param = reqObj.queryStr.id;

   // ** query param check
   const phone = typeof(param) === "string" && param.trim().length === 11 ? param : false;
   
   // ** validation check for reciving data
   const firstname = typeof(body.firstname) === "string" && body.firstname.trim().length > 0 ? body.firstname : false;

   const lastname = typeof(body.lastname) === "string" && body.lastname.trim().length > 0 ? body.lastname : false;

   const password = typeof(body.password) === "string" && body.password.trim().length > 0 ? body.password : false;

   const agreement = typeof(body.agreement) === "boolean" && body.agreement === true ? true : false;

   // ** do the next step
   if(phone){
      // ** variafication
      verify(token, phone, (varified) => {
         if(varified) {
            if(firstname || lastname || password) {
               // ** read the db
               data.read(userDir, phone, (readErr, readData) => {
                  if(!readErr && readData) {
                     const userData = {...parseJson(readData)};
      
                     if(firstname) {
                        userData.firstname = firstname;
                     }
      
                     if(lastname) {
                        userData.lastname = lastname;
                     }
      
                     if(password) {
                        userData.password = hash(password);
                     }
      
                     // ** store the db
                     data.update(userDir, phone, userData, (err) => {
                        if(!err) {
                           callback(200, {
                              message : "Sucess to update"
                           });
                        } else {
                           callback(500, {
                              error : "Internal Server Error"
                           })
                        }
                     })
      
                  } else {
                     callback(400, {
                        error : "Bad Request. Phone Number Was not match"
                     })
                  }
               })
            } else {
               callback(406, {
                  error : "Not acceptable, Need some body Element"
               })
            }
         } else {
            callback(403, {
               error : "Forbidden Connection"
            })
         }
      })

   } else {
      callback(400, {
         error : "Bad Request. Phone Number is invalid"
      })
   }
}

// ** user delete method
handler._user.delete = (reqObject, callback, token) => {
   const reqObj = reqObject;
   const param = reqObj.queryStr.id;

   // ** param validation check 
   const phone = typeof(param) === "string" && param.trim().length > 0 ? param : false;

   // ** delete operation 
   if(phone) {
      // ** vairfication
      verify(token, phone, (varified) => {
         if(varified) {
            // ** look the db, user are exit or not
            data.read(userDir, phone, (readErr, userData) => {
               if(!readErr && userData) {
                  // ** remove the user from db
                  data.delete(userDir, phone, (err) => {
                     if(!err) {
                        callback(200, {
                           message : "Sucess to Delete"
                        })
                     } else {
                        callback( 500, {
                           error : "Internal Server Error 204"
                        })
                     }
                  })
               } else {
                  callback( 204 , {
                     error : "No User was found"
                  })
               }
            })
         } else {
            callback(403, {
               error : "Forbidden Connection"
            })
         }
      })

   } else{
      callback(400, {
         error : "Bad Request. Phone is invalid"
      })
   }

}
// ** Export
module.exports = handler;