// * ========
// *
// * Title :  Check Routers
// * Description :  Check Routers
// * Author :  MD. Yeachen Abir
// * Title :  4 Octorbar 2024
// * 
// * =========


// ** Dependencies
const { chooseEnv } = require("../../helpers/enviroment");
const { parseJson, randomStr } = require("../../helpers/utilities");
const data = require("../../lib/data");
const { verify } = require("./tokens");


// ** Scaffolding
const handler = {}

// ** dir name
handler.tokenDir = "tokens";
handler.userDir = "users";
handler.checkDir = "checks";


// ** check operation
handler.check = (requestObj, callback) => {
   // ** acepted method
   const aceptedMethod = ['post', 'get', 'put', 'delete'];

   // * request Object
   const reqObj = requestObj;

   if(aceptedMethod.indexOf(reqObj.method) > -1){
      handler._check[reqObj.method](reqObj, callback);
   }else {
      callback(405, {
         message : "Request Method was not accepted"
      })
   }
}


// ** check method scaffolding
handler._check = {}

// ** post
handler._check.post = (requestObj, callback) => {
   const reqObj = requestObj;

   // ** validation check
   const protocol = typeof(reqObj.bodyObj.protocol) === "string" && ["http", "https"].indexOf(reqObj.bodyObj.protocol) ? reqObj.bodyObj.protocol : false;

   const url = typeof(reqObj.bodyObj.url) === "string" && reqObj.bodyObj.url.trim().length > 0 ? reqObj.bodyObj.url : false;

   const method = typeof(reqObj.bodyObj.method) === "string" && ['post', 'get', 'put', 'delete'].indexOf(reqObj.bodyObj.method) ? reqObj.bodyObj.method : false;

   const sucess = typeof(reqObj.bodyObj.sucessCode) === "object" && reqObj.bodyObj.sucessCode instanceof Array ? reqObj.bodyObj.sucessCode : false;

   const time = typeof(reqObj.bodyObj.time) === "number" && reqObj.bodyObj.time > 0 && reqObj.bodyObj.time < 6 && reqObj.bodyObj.time % 1 === 0 ? reqObj.bodyObj.time : false;


   if(protocol && url && method && sucess && time) {
      // ** parameter validation check
      const token = typeof(reqObj.header.token) === "string" && reqObj.header.token.trim().length === 20 ? reqObj.header.token : false;

      // ** look up the token db
      data.read(handler.tokenDir, token, (trErr, tokenStr) => {
         // ** get the token Object
         const tokenObj = { ... parseJson(tokenStr)};
         const phone = tokenObj.phone;
         // look up the user db
         data.read(handler.userDir, phone, (urErr, userStr) => {
            if(!urErr && userStr) {
               verify(token, phone, (tokenValid) => {
                  if(tokenValid) {
                     const userObj = {... parseJson(userStr)};
                     const userCheck = typeof(userObj.checks) === "object" && userObj.checks instanceof Array ? userObj.checks : [];

                     if(userCheck.length <= chooseEnv.maxCheck){
                        const checkId = randomStr(20);

                        // Make check object to register db
                        const checkObj = {
                           checkId,
                           protocol,
                           url,
                           method,
                           sucess,
                           time,
                           phone
                        };

                        // ** register to the db
                        data.create(handler.checkDir, checkId, checkObj, (checkErr) => {
                           if(!checkErr) {
                              // ** add the check object to the user db
                              userObj.checks = userCheck;
                              userObj.checks.push(checkId);

                              // ** update the user db
                              data.update(handler.userDir, phone, userObj, (updateERr) => {
                                 if(!updateERr) {
                                    callback(201, {
                                       message : "Sucess to create your check",
                                       checkId : checkId
                                    })
                                 } else {
                                    callback(500, {
                                       error : "Server Side Error"
                                    })
                                 }
                              })
                           } else {
                              callback(500, {
                                 error : "Server Side Error"
                              })
                           }
                        })

                     } else {
                        callback(401, {
                           error : `Already register max check ${chooseEnv.maxCheck} ${userCheck.length}`
                        })
                     }

                  } else {
                     callback(403, {
                        error : "Authontication Failed"
                     })
                  }
               })
            } else {
               callback(406, {
                  error : "Not Acceptable"
               })
            }
         })
      });
   } else { 
      callback(406, {
         error : "Not Acceptable"
      })
   }
}

// ** get
handler._check.get = (requestObj, callback) => {
   
   const reqObj = requestObj;

   // ** validation check
   const checkId = typeof(reqObj.queryStr.id) === "string" && reqObj.queryStr.id.trim().length === 5 ? reqObj.queryStr.id : false;


   const tokenId = typeof(reqObj.header.token) === "string" && reqObj.header.token.trim().length === 20 ? reqObj.header.token : false;

   if(checkId && tokenId) {
      data.read(handler.checkDir, checkId, (checkErr, checkStr) => {
         if(!checkErr && checkStr) {
            const checkObj = {...parseJson(checkStr)};
            const phone = checkObj.phone;

            // * read the token
            verify(tokenId, phone, (valid) => {
               if(valid) {
                  callback(200, checkObj);
               } else {
                  callback(403, {
                     error : "Auth Failed. Token was invalid"
                  })
               }
            })
         } else {
            callback(406, {
               error : "Bad Request. Check Id is not match"
            })
         }
      })
   } else { 
      callback(406, {
         error : "Bad Request"
      })
   }
}

// ** put
handler._check.put = (requestObj, callback) => {
   const reqObj = requestObj;

   // received body data check
   const protocol = typeof(reqObj.bodyObj.protocol) === "string" && ['http', 'https'].indexOf(reqObj.bodyObj.protocol) > -1 ? reqObj.bodyObj.protocol : false;

   const url = typeof(reqObj.bodyObj.url) === "string" && reqObj.bodyObj.url.trim().length > 0 ? reqObj.bodyObj.url : false;

   const method = typeof(reqObj.bodyObj.method) === "string" && ['post', 'get', 'put', 'delete'].indexOf(reqObj.bodyObj.method) ? reqObj.bodyObj.method : false;

   const sucess = typeof(reqObj.bodyObj.sucessCode) === "object" && reqObj.bodyObj.sucessCode instanceof Array ? reqObj.bodyObj.sucessCode : false;

   const time = typeof(reqObj.bodyObj.time) === "number" && reqObj.bodyObj.time > 0 && reqObj.bodyObj.time < 6 && reqObj.bodyObj.time % 1 === 0 ? reqObj.bodyObj.time : false;

   // ** recieved check id
   
   const checkId = typeof(reqObj.queryStr.id) === "string" && reqObj.queryStr.id.trim().length === 5 ? reqObj.queryStr.id : false;

   // ** TOKEN
   const tokenId = typeof(reqObj.header.token) === "string" && reqObj.header.token.trim().length === 20 ? reqObj.header.token : false;

   if(checkId && tokenId) {
      if(protocol || method || url || sucess || time) {
         // read the check data
         data.read(handler.checkDir, checkId, (checkErr, checkStr) => {
            if(!checkErr && checkStr) {
               const checkObj = {... parseJson(checkStr)};
               const phone = checkObj.phone;

               // token validation check
               verify(tokenId, phone, (valid) => {
                  if(valid) {
                     if(protocol) {
                        checkObj.protocol = protocol;
                     }

                     if(method) {
                        checkObj.method = method;
                     }

                     if(url) {
                        checkObj.url = url;
                     }

                     if(sucess) {
                        checkObj.sucess = sucess;
                     }

                     if(time) {
                        checkObj.time = time;
                     }

                     // ** update the db
                     data.update(handler.checkDir, checkId, checkObj, (updateErr) => {
                        if(!updateErr) {
                           callback(200, checkObj);
                        } else {
                           callback(500, {
                              error : "Server Side Error"
                           })
                        }
                     })
                   
                  } else {
                     callback(403, {
                        error : "Auth Failed"
                     })
                  }
               })
            } else {
               callback(406, {
                  error : "Invalid chcek id"
               })
            }
         })
      } else {
         callback(400, {
            error : "Problem in your request"
         })
      }
   } else {
      callback(406, {
         error : "Bad Request"
      })
   }
}

// ** delete
handler._check.delete = (requestObj, callback) => {
   const reqObj = requestObj;
   
   // received data check
   const checkId = typeof(reqObj.queryStr.id) === "string" && reqObj.queryStr.id.trim().length === 5 ? reqObj.queryStr.id : false;

   const token = typeof(reqObj.header.token) === "string" && reqObj.header.token.trim().length === 20 ? reqObj.header.token : false;

   if(checkId && token) {
      data.read(handler.checkDir, checkId, (checkErr, checkStr) => {
         if(!checkErr && checkStr) {
            const checkObj = {... parseJson(checkStr)};
            const phone = checkObj.phone;

            // token verify
            verify(token, phone, (valid) => {
               if(valid) {
                  data.delete(handler.checkDir, checkId, (deleteErr) => {
                     if(!deleteErr) {
                        callback(200, {
                           message : "Sucess to delete"
                        })
                     } else {
                        callback(500, {
                           error : "Server Side Error"
                        })
                     }
                  })
               } else {
                  callback(403, {
                     error : "Auth failed. Token id was expire."
                  })
               }
            })
         } else {
            callback(406, {
               error : "Check Id was invalid"
            })
         }
      })
   } else {
      callback (406, {
         error : "Bad Request"
      })
   }

}


// ** Export
module.exports = handler;
