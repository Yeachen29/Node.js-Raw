// * ========
// *
// * Title :  Sample Page Routers
// * Description :  Sample Page Routers
// * Author :  MD. Yeachen Abir
// * Title :  4 Octorbar 2024
// * 
// * =========

// ** Dependencies

// ** Scaffolding
const handlerRoutes = {}

// ** handler sample routers
handlerRoutes.sample = (reqObj, callback) => {
   callback(200, {
      message : "Sample Page"
   })
}
// ** Export
module.exports = handlerRoutes;