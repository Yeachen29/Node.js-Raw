// * ========
// *
// * Title :  Token Section
// * Description :  Token Operation
// * Author :  MD. Yeachen Abir
// * Title :  4 Octorbar 2024
// * 
// * =========

// ** Dependencies
const data = require('./../../lib/data');
const { hash, parseJson, randomStr } = require('./../../helpers/utilities');

// ** Scaffolding
const handler = {}

// ** directory
handler.userDir = "users";
handler.tokenDir = "tokens";

// ** token operation function
handler.token = (reqObject, callback) => {
   const reqObj = reqObject;
   const acceptMethod = ['post', 'get', 'put', 'delete'];

   // ** call the function accroding to method
   if(acceptMethod.indexOf(reqObj.method) > -1){
      handler._token[reqObj.method](reqObj, callback);
   } else {
      callback(405, {
         error : "Method Not allow"
      })
   }
}

// ** token method scaffolding
handler._token = {}

// ** Post token
handler._token.post = (reqObject, callback) => {
   const reqObj = reqObject;
   const body = reqObj.bodyObj;
   // ** validation checked
   const id = typeof(body.phone) === "string" && body.phone.trim().length === 11 ? body.phone : false;

   const password = typeof(body.password) === "string" && body.password.length > 0 ? body.password : false;

   if(id && password){
      // ** read the user accroding to id
      data.read(handler.userDir, id, (readErr, userData) => {
         if(!readErr && userData) {
            const hashPass = hash(password);
            const user = {...parseJson(userData)};
            
            // ** match the password
            if(hashPass === user.password){
               const token = randomStr(20);
               const expire = Date.now() + (6 * 60 * 60 * 1000);
               // add token obj in the userObject
               const tokenObj = {
                  phone : id,
                  token,
                  expire
               }

               // ** save the database
               data.create(handler.tokenDir, token, tokenObj, (createErr) =>{
                  if(!createErr){
                     data.update(handler.userDir, id, user, (updateErr) => {
                        if(!updateErr){
                           callback(201, tokenObj);
                        } else {
                           callback(500, {
                              error : "Server Side Error"
                           })
                        }
                     })
                  }else{
                     callback(500, {
                        error : "Server Side Error"
                     })
                  }
               })       
            } else {
               callback(400, {
                  error : "Password is not valided"
               })
            }

         } else {
            callback(400, {
               error : "Bad Request. No User found"
            })
         }
      })
   } else {
      callback(400, {
         error : "Bad Request"
      })
   }
}

// ** Get token
handler._token.get = (reqObject, callback) => {
   const reqObj = reqObject;
   const token = typeof(reqObj.queryStr.token) === "string" && reqObj.queryStr.token.trim().length === 20 ? reqObj.queryStr.token : false;

   if(token) {
      data.read(handler.tokenDir, token, (readErr, tokenStr) => {
         if(!readErr && tokenStr) {
            const tokenObj = {...parseJson(tokenStr)}
            callback(200, tokenObj);
         } else {
            callback(400, {
               error : "Token was not found"
            })
         }
      })
   }else {
      callback(404, {
         error : "Invalid Token"
      })
   }
}


// ** Put token
handler._token.put = (reqObject, callback) => {
   const reqObj = reqObject;
   // token validation checked
   const token = typeof(reqObj.queryStr.token) === "string" && reqObj.queryStr.token.trim().length === 20 ? reqObj.queryStr.token : false;
    // validation checked
    const expireExpand = typeof(reqObj.bodyObj.expire) === "boolean" && reqObj.bodyObj.expire === true ? true : false;

   if(token && expireExpand) {
      // ** read the db
      data.read(handler.tokenDir, token, (rErr, tokenstr) => {
         if(!rErr && tokenstr) {
            const tokenObj = {...parseJson(tokenstr)};
            if(tokenObj.expire > Date.now()) {
               tokenObj.expire =Date.now() + (6 * 60 * 60 * 1000);
               data.update(handler.tokenDir, token, tokenObj, (uErr) => {
                  if(!uErr) {
                     callback(200, {
                        message : "Sucess to expand you token validation time"
                     })
                  } else { 
                     callback(500, {
                        error : "Server Side Error"
                     })
                  }
               })
            } else {
               callback(401, {
                  error : "Token already expire. Create another one"
               })
            }
         } else {
            callback(400, {
               error : "Bad Request. token are missing"
            })
         }
      })

   } else {
      callback(400, {
         error : "Bad Request. token is invalid"
      })
   }
}


// ** delete token
handler._token.delete = (reqObject, callback) => {
   const reqObj = reqObject;
   const token = typeof(reqObj.queryStr.token) === "string" && reqObj.queryStr.token.trim().length === 20 ? reqObj.queryStr.token : false;

   if(token) {
      data.read(handler.tokenDir, token, (rErr, tokenData) => {
         if(tokenData & !rErr) {
            data.delete(handler.tokenDir, token, (deleteErr) => {
         if(!deleteErr) {
            callback(200, {
               message : "Sucess To Deleted"
            })
         } else { 
            callback(500, {
               error : "Server Side Error"
            })
         }
      })
         } else{
            callback(404, {
               error : "Missing Data"
            })
         }
      })
   } else { 
      callback(404, {
         error : "Invalid Token"
      })
   }
}


// ** token varification
handler.verify = (tokenId, phone, callback) => {
   // ** read the db
   data.read(handler.tokenDir, tokenId, (rErr, tokenstr) => {
      if(!rErr && tokenstr) {
         const tokenObj = parseJson(tokenstr);
         if(phone === tokenObj.phone && tokenObj.expire > Date.now()) {
            callback(true);
         } else {
            callback(false);
         }
      } else {
         callback(false);
      }
   })
}

// ** Export
module.exports = handler;