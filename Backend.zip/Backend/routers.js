// * ========
// *
// * Title :  Routers
// * Description :  Routers
// * Author :  MD. Yeachen Abir
// * Title :  4 Octorbar 2024
// * 
// * =========

// ** Dependencies
const { sample } = require("./handler/routersHandler/sample");
const { users } = require("./handler/routersHandler/users");
const { token } = require("./handler/routersHandler/tokens");
const { check } = require("./handler/routersHandler/check");

// ** Scaffolding
const routers = {
   sample,
   users,
   token, 
   check
}

// ** Export
module.exports = routers;