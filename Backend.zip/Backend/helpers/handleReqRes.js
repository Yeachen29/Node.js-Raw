// * ========
// *
// * Title :  Handler Request Response
// * Description :  Handler Request Response
// * Author :  MD. Yeachen Abir
// * Title :  4 Octorbar 2024
// * 
// * =========

// ** Dependencies
const url = require('url');
const { StringDecoder} = require('string_decoder');
const { parseJson } = require('./utilities');
const routers = require('./../routers');
const { notFound } = require('./../handler/routersHandler/notFound');

// ** Scaffolding
const handler = {}

// ** handlerReqRes function
handler.handleReqRes = (req, res) => {
   const myUrl = url.parse(req.url, true);
   const path = myUrl.pathname;
   const trimPath = path.replace(/^\/+|\/+$/g, "");
   const method = req.method.toLowerCase();
   const queryStr = myUrl.query;
   const header = req.headers;
   let body = "";
   const decoder = new StringDecoder('utf-8')
   req.on('data', (buffer)=> {
      body += decoder.write(buffer);

   });
   req.on("end", ()=>{
      body += decoder.end();
      const bodyObj = parseJson(body); 
      const reqObj = {
         path,
         trimPath,
         method,
         queryStr,
         header,
         bodyObj
      }

      const chooseHandler = routers[trimPath] ? routers[trimPath] : notFound;
      
      chooseHandler(reqObj, (statusCode, payload)=>{
         statusCode = typeof(statusCode) === "number" ? statusCode : 500;
         payload = typeof(payload) === "object" ? payload : {};
         const payloadStr = JSON.stringify(payload);


         res.setHeader("content-type", "application/json");
         res.writeHead(statusCode);
         res.write(payloadStr);
         res.end();

      });
   })

}
// ** Export
module.exports = handler;