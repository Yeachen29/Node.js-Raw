// * ========
// *
// * Title :  Enviroment
// * Description :  Enviroment 
// * Author :  MD. Yeachen Abir
// * Title :  4 Octorbar 2024
// * 
// * =========

// ** Dependencies

// ** Scaffolding
const env = {}

// ** Straging enviroment
env.straging = {
   port : 3000,
   enviroment : "straging",
   keys : "kdoiru93u489r@@#$%^*kdfjiour",
   maxCheck : 5,
   twilioSMS : {
      fromPhone : "01795477717",
      sid : "AC6d53ca256a9aaf9e505cd50d273821fc",
      token : "69cb969ca7f232506e82f70b2d486b99"
   }
}

// ** Production enviroment
env.production = {
   port : 5000,
   enviroment : "production",
   keys : "k3u489r@@#$%^swe344doiru9*kdfjiour",
   maxCheck : 5,
   twilioSMS : {
      fromPhone : "01795477717",
      sid : "AC6d53ca256a9aaf9e505cd50d273821fc",
      token : "69cb969ca7f232506e82f70b2d486b99"
   }
}

// ** select the right enviroment
const currentEnv = typeof(process.env.NODE_ENV) === "string" ? process.env.NODE_ENV : "staging";

env.chooseEnv = typeof(env[currentEnv]) === "object" ? env[currentEnv] : env.straging;

// ** Export
module.exports = env;