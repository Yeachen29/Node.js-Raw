// * ========
// *
// * Title :  Notification
// * Description :  Notification
// * Author :  MD. Yeachen Abir
// * Title :  4 Octorbar 2024
// * 
// * =========

// ** Dependencies
const https = require('https');
const { chooseEnv } = require('./enviroment');
const { stringify } = require('querystring');



// ** Scaffolding
const notification = {}




// ** notification operation
notification.sendSMS = (phoneNum, massage, callback) => {
   // ** received data validation check
   const phone = typeof(phoneNum) === "string" && phoneNum.trim().length === 11 ? phoneNum.trim() : false;

   const msg = typeof(massage) === "string" && massage.trim().length > 0 && massage.trim().length <= 1600 ? massage.trim() : false;
   

   if(phone && msg){
      const payload = {
         from : chooseEnv.twilioSMS.fromPhone,
         body : msg,
         to : phone
      }

      // ** object to string
      const payloadStr = stringify(payload);

      // ** request Detials
      const reqDet = {
         hostname: 'api.twilio.com',
         path: `/2010-04-01/Accounts/${chooseEnv.twilioSMS.sid}/Messages.json`,
         method: 'POST',
         auth : `${chooseEnv.twilioSMS.sid}:${chooseEnv.twilioSMS.keys}`,
         headers : {
            "Content-Type" : "application/x-www-form-urlencoded"
         }
       };


       // ** create request
       const req = https.request(reqDet, (res) => {
         const statusCode = res.statusCode;
         if(statusCode === 200 || statusCode === 201 || statusCode === 301) {
            callback(false);
         } else {
            callback(`Status Code ${statusCode}`)
         }
       })
       req.on('error', (e) => {
         console.error(e);
       });
       req.write(payloadStr);
       req.end();

   } else {
      callback('Invalid Input');
   }

}

// ** Export
module.exports = notification;