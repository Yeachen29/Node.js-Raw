// * ========
// *
// * Title :  Utilities
// * Description :  Utilities
// * Author :  MD. Yeachen Abir
// * Title :  4 Octorbar 2024
// * 
// * =========

// ** Dependencies
const crypto = require('crypto');
const env = require('./enviroment');

// ** Scaffolding
const utilities = {}

// ** string parser
utilities.parseJson = (string) => {
   let output;
   try{
      output = JSON.parse(string);
   }catch{
      output = {};
   }
   return output;
}

// ** hashing
utilities.hash = (str) => {
   if(typeof(str) === "string" && str.length > 0){
      const hashing = crypto.createHmac('sha256', env.chooseEnv.keys)
      .update(str)
      .digest('hex');

      return hashing;
   }else{

   }
}

// ** random string
utilities.randomStr = (stringLength) => {
   const length = typeof(stringLength) === "number" && stringLength > 0 ? stringLength : false;
   const character = "abcdefghijklmnopqrstuvwxyz@!$&1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";

   if(length) {
      let output = "";
      for (let i = 0; i < length; i++) {
         const randomCharc = character.charAt(Math.floor(Math.random() * length));

         output += randomCharc;
      }
      return output;
   } else {
      return false;
   }
}

// ** Export
module.exports = utilities;