// ** ==================
User Area


User Post: ====
User Field
   firstname
   lastname
   phone
   password
   agreement

User Get: ====
send with header :
token : tokenid

Param : Phone number
like : url/id:Phone

User Put: ====
send with header :
token : tokenid

Param : Phone number
like : url/id:Phone
Also 
User Field
   firstname
   lastname
   phone
   password
   agreement



User delete: ====
send with header :
token : tokenid

Param : Phone number
like : url/id:Phone

// ** ==================



// ** ==================
Token Area

Create Token for six our

Token Post: ====
Token Field
phone: User Phone Number
password : User Password

example : 
{
   "phone" : "",
   "password" : ""
}

Token Get: ====
parameter
token="tokenid"

Token Put: ====
parameter
token="tokenid"
body
expire:boolean

 


// ** ==================


// ** ==================
Check Area


// * post
Required Field
protocol :
url : 
method : 
sucessCode : 
time : 

Require header
token : tokenid


// * get
id : check id as a parameter
example:
url/check?id=checkId
Require header
token : tokenid

// * delete
id : check id as a parameter
example:
url/check?id=checkId
Require header
token : tokenid

// * put
id : check id as a parameter
example:
url/check?id=checkId
Require header
token : tokenid

as a body
Required Field
protocol :
url : 
method : 
sucessCode : 
time : 

// ** ==================





Basic Stucture
// * ========
// *
// * Title :  UpTime Application
// * Description :  UpTime Monitoring Application
// * Author :  MD. Yeachen Abir
// * Title :  4 Octorbar 2024
// * 
// * =========

// ** Dependencies

// ** Scaffolding

// ** Export













"firstname" : "Yeachen",
"lastname" : "Abir",
"phone" : "01739106010",
"password" : "12345",
"agreement" : true